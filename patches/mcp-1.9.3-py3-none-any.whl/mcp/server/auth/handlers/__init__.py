"""
Request handlers for MCP authorization endpoints.
"""
